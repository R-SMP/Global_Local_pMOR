function [Kr, Gr, Mr, Br, Cr, s] = SO_IRKA_SISO(K, G, M, B, C, s, proj, tol, maxiter)
%SO_IRKA_SISO_us SO-IRKA with adaptive order
%   Inputs: M, G, K, B, C : system
%           s : initial expansion points
%           tol : convergence tolerance
%           proj : projection method (one-sided, two-sided)
%           maxiter : max number of iterations

if ~(strcmpi(proj, 'os') || strcmpi(proj, 'ts'))
    error('unknown projection method')
end

s = s(:);
r = length(s);
s = cplxpair(s);
Vr = zeros(size(M,1),r);
Wr = zeros(size(M,1),r);

fprintf('Starting initial basis computation...')
timer_initial = tic;
for ii = 1:r/2
    tmp1 = s(2*ii)^2*M + s(2*ii)*G + K;
    x = tmp1\B;
    Vr(:,2*ii-1) = real(x);
    Vr(:,2*ii) = imag(x);
    
    if strcmp(proj, 'ts')
        x = C / tmp1;
        Wr(:,2*ii-1) = real(x);
        Wr(:,2*ii) = imag(x);
    end
end

[Vr, ~] = qr(Vr,0);
if strcmp(proj, 'ts')
    [Wr, ~] = qr(Wr,0);
else
    Wr = Vr;
end
fprintf(' finished in %f s.\n', toc(timer_initial))

iter = 1;
err = 1;
while (iter <= maxiter) && (err > tol)
    fprintf('Starting iteration i=%d with order r=%d...\n',iter,r)
    s_old = s;
    
    Mr = Wr' * M * Vr;
    Gr = Wr' * G * Vr;
    Kr = Wr' * K * Vr;
    
    lam = polyeig(Kr,Gr,Mr);
    
    % remove real and unstable eigenvalues
    lam(imag(lam) == 0) = [];
    lam(real(lam) > 0) = [];
    
    % sort for the eigenvalues next to the imaginary axis
    [~,order] = sort(abs(imag(lam)),'ascend');
    
    % choose expansion point as mirror images of eigenvalues
    s = -lam(order);
    s = s(1:r);

    % sort again
    s = cplxpair(s);

    
    % expand basis
    Vr = zeros(size(M,1),r);
    Wr = zeros(size(M,1),r);
    for ii = 1:r/2
        tmp1 = s(ii*2)^2*M + s(ii*2)*G + K;
        x = tmp1\B;
        Vr(:,2*ii-1) = real(x);
        Vr(:,2*ii) = imag(x);
        
        if strcmp(proj, 'ts')
            x = C / tmp1;
            Wr(:,2*ii-1) = real(x);
            Wr(:,2*ii) = imag(x);
        end
        
    end
    
    % orthogonalize
    [Vr, ~] = qr(Vr,0);
    if strcmp(proj, 'ts')
        [Wr, ~] = qr(Wr,0);
    else
        Wr = Vr;
    end
    
    % convergence
    err = norm(sort(s,'ComparisonMethod','abs') - ...
        sort(s_old,'ComparisonMethod','abs'))/norm(s_old);
    fprintf('\terr = %e.\n',err)
    
    iter = iter + 1;
    
end

Mr = Wr' * M * Vr;
Gr = Wr' * G * Vr;
Kr = Wr' * K * Vr;
Br = Wr' * B;
Cr = C * Vr;
% hold off

end

